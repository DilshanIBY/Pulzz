﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Hospital_Management_System
{
    public partial class frmAdminDashboard : Form
    {
        SqlConnection conn = new SqlConnection("Data Source=MSI\\SQLEXPRESS;Initial Catalog=Hospital_Management_System;Integrated Security=True;");
        SqlCommand cm = new SqlCommand();


        SqlDataReader dr;
        SqlDataReader drr;

        [DllImport("Gdi32.dll", EntryPoint = "CreateRoundRectRgn")]
        private static extern IntPtr CreateRoundRectRgn
       (
           int nLeftRect,     // x-coordinate of upper-left corner
           int nTopRect,      // y-coordinate of upper-left corner
           int nRightRect,    // x-coordinate of lower-right corner
           int nBottomRect,   // y-coordinate of lower-right corner
           int nWidthEllipse, // width of ellipse
           int nHeightEllipse // height of ellipse
       );

        public frmAdminDashboard()
        {
            InitializeComponent();
            this.FormBorderStyle = FormBorderStyle.None;
            Region = System.Drawing.Region.FromHrgn(CreateRoundRectRgn(0, 0, Width, Height, 20, 20));
            pLoad();
            pageLoad();
            pageLoadtb();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Are You Sure You Want to Close This Application?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            frmAccessControl hp = new frmAccessControl();
            panel3.Controls.Add(hp);
            hp.BringToFront();
            hp.Show();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
           

            frmSettings hp = new frmSettings();
            panel3.Controls.Add(hp);
            hp.BringToFront();
            hp.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        public void pLoad()
        {
            conn.Open();
            cm = new SqlCommand("select formName from tblFormCustomize", conn);
            dr = cm.ExecuteReader();

            // Clear existing text from label
            label1.Text = "";

            while (dr.Read())
            {
                // Append each formName to the label's text with a line break
                label1.Text += dr["formName"].ToString() + Environment.NewLine;
            }

            dr.Close();
            conn.Close();
        }

        public void pageLoad()
        {
            conn.Open();
            cm = new SqlCommand("select sbColor from tblFormCustomize", conn);
            dr = cm.ExecuteReader();


            if (dr.HasRows)
            {

                dr.Read();

                string colorName = dr["sbColor"].ToString();

                dr.Close();


                conn.Close();

                panel1.BackColor = Color.FromName(colorName);
            }
            else
            {

                dr.Close();
                conn.Close();
 
                panel1.BackColor = Color.Blue;
            }
        }

        public void pageLoadtb()
        {
            conn.Open();
            cm = new SqlCommand("select tbColor from tblFormCustomize", conn);
            dr = cm.ExecuteReader();


            if (dr.HasRows)
            {

                dr.Read();

                string colorName = dr["tbColor"].ToString();

                dr.Close();


                conn.Close();

                panel2.BackColor = Color.FromName(colorName);
            }
            else
            {

                dr.Close();
                conn.Close();

                panel1.BackColor = Color.Blue;
            }
        }

        private void frmAdminDashboard_Load(object sender, EventArgs e)
        {

        }
    }
}

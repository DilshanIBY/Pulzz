﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Hospital_Management_System
{
    public partial class frmFormCustomize : UserControl
    {
        SqlConnection conn = new SqlConnection("Data Source=MSI\\SQLEXPRESS;Initial Catalog=Hospital_Management_System;Integrated Security=True;");
        SqlCommand cm = new SqlCommand();


        SqlDataReader dr;
        SqlDataReader drr;
        public frmFormCustomize()
        {
            InitializeComponent();
            LoadRecord1();
        }

      

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
        public void LoadRecord1()
        {

            conn.Open();
            cm = new SqlCommand("select formName from tblFormCustomize", conn);
            dr = cm.ExecuteReader();
            while (dr.Read())
            {
                comboBox4.Items.Add(dr["formName"].ToString());
            }
            dr.Close();
            conn.Close();
        }
        private void frmFormCustomize_Load(object sender, EventArgs e)
        {

        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM tblFormCustomize WHERE formName = @formName", conn);
                cmd.Parameters.AddWithValue("@formName", comboBox4.SelectedItem.ToString());
                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.Read())
                {
                    comboBox4.Text = dr["formName"].ToString();
                    comboBox3.Text = dr["sbColor"].ToString();
                    comboBox2.Text = dr["tbColor"].ToString();
                    comboBox1.Text = dr["btnColir"].ToString();
                    id.Text = dr["id"].ToString();


                }
                else
                {
                    // Clear the TextBox if no matching record is found
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Are you sure you want to update this Record...?", "Update Record", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {

                    conn.Open();
                    cm = new SqlCommand("UPDATE tblFormCustomize SET formName=@formName,sbColor=@sbColor,tbColor=@tbColor,btnColir=@btnColir,id=@id where id like @id", conn);
                    cm.Parameters.AddWithValue("@formName", comboBox4.Text);
                    cm.Parameters.AddWithValue("@sbColor", comboBox3.Text);
                    cm.Parameters.AddWithValue("@tbColor", comboBox2.Text);
                    cm.Parameters.AddWithValue("@btnColir", comboBox1.Text);
                    cm.Parameters.AddWithValue("@id", id.Text);




                    cm.ExecuteNonQuery();
                    conn.Close();
                    MessageBox.Show("Record has been successfully updated.");


                }
            }
            catch (Exception ex)
            {
                conn.Close();
                MessageBox.Show(ex.Message);
            }
           
        }
    }
}

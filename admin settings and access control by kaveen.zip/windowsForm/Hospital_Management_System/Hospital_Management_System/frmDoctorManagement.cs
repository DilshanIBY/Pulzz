﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Hospital_Management_System
{
    public partial class frmDoctorManagement : UserControl
    {

        SqlConnection conn = new SqlConnection("Data Source=MSI\\SQLEXPRESS;Initial Catalog=Hospital_Management_System;Integrated Security=True;");
        SqlCommand cm = new SqlCommand();


        SqlDataReader dr;
        SqlDataReader drr;

        public frmDoctorManagement()
        {
            InitializeComponent();
            LoadRecord1();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Are You Sure You Want to Add this Record?", "", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    conn.Open();
                    cm = new SqlCommand("INSERT INTO DoctorRegistration(username,name,job_role,address,email,number,password) VALUES(@username,@name,@job_role,@address,@email,@number,@password)", conn);

                    cm.Parameters.AddWithValue("@username", comboBox3.Text);
                    cm.Parameters.AddWithValue("@name", textBox1.Text);
                    cm.Parameters.AddWithValue("@job_role", textBox2.Text);
                    cm.Parameters.AddWithValue("@address", textBox3.Text);
                    cm.Parameters.AddWithValue("@email", textBox5.Text);
                    cm.Parameters.AddWithValue("@number", textBox4.Text);
                    cm.Parameters.AddWithValue("@password", textBox6.Text);


                    cm.ExecuteNonQuery();
                    conn.Close();
                    MessageBox.Show("Record Added successfully");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {               
                conn.Close();             
            }
        }

        public void LoadRecord1()
        {

            conn.Open();
            cm = new SqlCommand("select username from DoctorRegistration", conn);
            dr = cm.ExecuteReader();
            while (dr.Read())
            {
                comboBox3.Items.Add(dr["username"].ToString());
            }
            dr.Close();
            conn.Close();
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                conn.Open();
                SqlCommand cmd = new SqlCommand("SELECT * FROM DoctorRegistration WHERE username = @username", conn);
                cmd.Parameters.AddWithValue("@username", comboBox3.SelectedItem.ToString());

                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.Read())
                {
                    textBox1.Text = dr["name"].ToString();
                    textBox2.Text = dr["job_role"].ToString();
                    textBox3.Text = dr["address"].ToString();
                    textBox5.Text = dr["email"].ToString();
                    textBox4.Text = dr["number"].ToString();
                    textBox6.Text = dr["password"].ToString();
             
                }
                else
                {
                    textBox1.Clear(); // Clear the TextBox if no matching record is found
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Are you sure you want to update this Record...?", "Update Record", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {

                    conn.Open();
                    cm = new SqlCommand("UPDATE DoctorRegistration SET username=@username,name=@name,job_role=@job_role,address=@address,email=@email,number=@number,password=@password where username like @username", conn);
                    cm.Parameters.AddWithValue("@username", comboBox3.Text);
                    cm.Parameters.AddWithValue("@name", textBox1.Text);
                    cm.Parameters.AddWithValue("@job_role", textBox2.Text);
                    cm.Parameters.AddWithValue("@address", textBox3.Text);
                    cm.Parameters.AddWithValue("@email", textBox5.Text);
                    cm.Parameters.AddWithValue("@number", textBox4.Text);
                    cm.Parameters.AddWithValue("@password", textBox6.Text);



                    cm.ExecuteNonQuery();
                    conn.Close();
                    MessageBox.Show("Record has been successfully updated.");


                }
            }
            catch (Exception ex)
            {
                conn.Close();
                MessageBox.Show(ex.Message);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                if (MessageBox.Show("Are you sure, Do you really want to Delete this Record...? ", "Delete Record", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                {
                    conn.Open();
                    using (SqlCommand cmd = new SqlCommand("DELETE FROM DoctorRegistration WHERE username = @username", conn))
                    {
                        cmd.Parameters.AddWithValue("@username", comboBox3.Text);
                        cmd.ExecuteNonQuery();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }

        private void frmDoctorManagement_Load(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}
